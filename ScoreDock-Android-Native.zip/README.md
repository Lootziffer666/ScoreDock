# ScoreDock Android (native wrapper)

This is a minimal native Android app that bundles the ScoreDock UI (from the provided compiled webapp) and displays it in a WebView.

## Build
1. Open this folder in Android Studio (Giraffe / Hedgehog or newer).
2. Let Gradle sync.
3. Run on an emulator or device.

The app loads: `file:///android_asset/www/index.html`
